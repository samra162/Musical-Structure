package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class NowPlaying extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_now_playing);

        Bundle setValuesToViews = getIntent().getExtras();
        String songNames = setValuesToViews.getString("songName");
        String artistNames = setValuesToViews.getString("artistName");
        int photoResourceID = setValuesToViews.getInt("songPhoto");

        TextView nameSong = findViewById(R.id.songName_textView);
        nameSong.setText(songNames);
        TextView nameArtist = findViewById(R.id.artistName_textView);
        nameArtist.setText(artistNames);
        ImageView nowPlayingPhoto = findViewById(R.id.nowPlaying_imageView);
        nowPlayingPhoto.setImageResource(photoResourceID);
    }
}