package com.example.android.musicalstructure;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class SongsList extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_songs_list);

        final ArrayList<Song> songs = new ArrayList<>();

        songs.add(new Song("A Little Bit Off", "Five Finger Death Punch", R.drawable.fivefinger_deathpunch));
        songs.add(new Song("Back In Black", "AC/DC", R.drawable.acdc));
        songs.add(new Song("Creep", "RadioHead", R.drawable.radio_head));
        songs.add(new Song("Dream On", "BlackTop Mojo", R.drawable.blacktop_mojo));
        songs.add(new Song("Grenade", "Bruno Mars", R.drawable.bruno_mars));
        songs.add(new Song("Hello", "Adele", R.drawable.adele));
        songs.add(new Song("Numb", "Linkin Park", R.drawable.linkin_park));
        songs.add(new Song("Stairway To Heaven", "Led Zeppelin", R.drawable.led_zeppelin));
        songs.add(new Song("My Immortal", "Evanescence", R.drawable.evanescence));
        songs.add(new Song("Wake Me Up", "Avicii", R.drawable.avicii));

        SongAdapter songsAdapter = new SongAdapter(this, songs);
        ListView songsList = findViewById(R.id.songs_list);
        songsList.setAdapter(songsAdapter);
        songsList.setOnItemClickListener((parent, view, position, id) -> {
            Song currentSong = songs.get(position);
            Intent playSong = new Intent(this, NowPlaying.class);
            playSong.putExtra("songName", currentSong.getSongName());
            playSong.putExtra("artistName", currentSong.getArtistName());
            playSong.putExtra("songPhoto" , currentSong.getImageResourceId());
            startActivity(playSong);
        });



    }
}